This Entity Maker is a windowed version of the original provided by The Game Creators. I have only made minor updates for my workflow with FPS Creator.

These updates are as follows:

Window size is 640x480

Updated materials to be correct in FPSC ie wood is now wood and not stone in FPSC

Gave only one folder for putting new entities instead of two. You now use just the folder Entity.

Updated icon 

Updated resolution to 32

Enjoy the changes to this simple great program! It has improved my workflow for greatly by making these changes. If you have problems with this program, I have included the original tutorial video files and my code for darkbasic. If you still have problems, you can email me starmind001@yahoo.com and explain your problem. Please be sure to give it the subject Entity Maker issue. This way I know what you are asking.

Thanks and Enjoy!!