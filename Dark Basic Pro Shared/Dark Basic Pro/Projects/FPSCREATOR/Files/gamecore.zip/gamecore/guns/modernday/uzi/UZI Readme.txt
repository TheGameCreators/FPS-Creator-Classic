Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

reload.wav

dryfire.wav

NEW EXTRA SOUNDS:

cock.wav

cases.wav (shared)

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... UZI

1. I've included a "quick-fix" gunspec file which sets up the reload and cock sounds to work with the animation (works well @~ 35fps). 

2. I've included "cases.wav" (empty shell cases hitting hard surface) in case you want to work them in somehow.  The problem with this sound is that it should vary based on the type of surface the player is meant to be standing on.  I can provide variations on this sound if required.

3. Included gunspec file must be used when auditioning this sound. 

That's it for for this one!
 
Rick Harrison.
