Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

reload.wav

dryfire.wav

NEW EXTRA SOUNDS:

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... Python

1. Sequencing of the fire animation is wrong.  This is a "Double-Action" Revolver, which means that as the trigger is pulled, the hammer moves backward and the cylinder rotates to align the next round with the receiver just prior to hammer fall and detonation.

In the EA model, the cylinder turns to align the next round with the receiver AFTER the shot is fired, which is impossible in reality.  I realise this might be getting picky, but it would be nice to get it right .

2. Modified gunspec file is needed for auditioning this sound set.

That's it for for this one!
 
Rick Harrison.
