Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

in \guns\scfi\glaive\...

throw.wav

Note... I don't believe a "pullpin" sound needs to be used for this weapon.
...................................................

in \flak\scfi\glaive\...

explode.wav

bounce.wav


NEW EXTRA SOUNDS:

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________

IMPROVEMENT RECOMMENDATIONS... Glaive

1. I've included a "quick-fix" gunspec file which sets up the throw sound to work with the animation (works well @~ 35fps).  Can't seem to get putaway and retrieve to be triggered as they should on any of the weapons, I guess this will be worked out later.

Included gunspec file shoud be used when auditioning this sound set.

Also, I can't stop "pullpin.wav" from firing when the "throw.wav" is fired.  It doesn't seem to be turn-offable(?!) in the gunspec file. 

That's it for for this one!
 
Rick Harrison.
