Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

reload.wav

dryfire.wav

NEW EXTRA SOUNDS:

windup.wav (to be used with "fire.wav" see gunspec file)

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... Minigun

1. I've included a "quick-fix" gunspec file which sets up the windup, fire and reload sounds to work with the animation (works well @~ 35fps). 

2. Created additional sound, "windup.wav" which is to be used in conjunction with the fire sound.  See included gunspec file. 

3. Included gunspec file is needed when auditioning this sound set.

4. Like the Vickers, this gun would benefit from a longer reload animation.

That's it for for this one!
 
Rick Harrison.
