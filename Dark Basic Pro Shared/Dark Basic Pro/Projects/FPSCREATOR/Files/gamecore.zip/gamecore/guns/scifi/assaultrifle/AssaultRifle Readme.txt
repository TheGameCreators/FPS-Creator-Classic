Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

reload.wav

dryfire.wav

NEW EXTRA SOUNDS:

cock.wav

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... AssaultRifle

1. I've included a "quick-fix" gunspec file which sets up the fire and reload sounds to work with the animation (works well @~ 35fps).  Included gunspec file is needed when auditioning this sound set.

Can't really think of any improvements on this weapon, except perhaps for the re-load animation.  Other than that, with the new sounds, it works well!

That's it for for this one!
 
Rick Harrison.
