Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

reload.wav

cock.wav

dryfire.wav

NEW EXTRA SOUNDS:

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... Blaster

1. I've included a "quick-fix" gunspec file which sets up the fire and reload sounds to work with the animation (works well @~ 35fps).  Can't seem to get putaway and retrieve to be triggered as they should on any of the weapons, I guess this will be worked out later.

Included gunspec file shoud be used when auditioning this sound set.

I would like to see this weapon fire a small high speed projectile (Energy bolt?) that is visible from gun to target with an intense  light-source attached, if not too much of a drain on the engine.

On striking the target, rather than leaving a bullet hole, I think a scorch mark  would be more appropriate.

That's it for for this one!
 
Rick Harrison.
