Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

in \guns\ww2\milsno36\...

pullpin.wav

throw.wav

...................................................

in \flak\ww2\milsno36\...

explode.wav

bounce.wav


NEW EXTRA SOUNDS:

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________

In addition to auditioning the sounds in FPSC, please listen to the demo included in the zip.  This will give a better idea of how the new sounds will work when the sound/animation sequencing is sorted within FPSC.

Demo sequence:

retrieve, pullpin, throw, bounce, explode  (putaway not used in demo)

IMPROVEMENT RECOMMENDATIONS... MillsNo 36 Grenade

1. The current sound triggering sequence, when "fire" is pressed, is pullpin, throw and pullpin (together).  Should be pullpin, throw, pause ~500msec (with no grenade on screen), retrieve (and display next grenade).

That's it for for this one!
 
Rick Harrison.
