Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

reload.wav

dryfire.wav

NEW EXTRA SOUNDS:

cock.wav

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... Colt 45

1. Recoil animation too late.  Should start at the instant of firing.

2. The sound "reload.wav" is triggered twice during re-load and cock animation.  Should trigger once followed immediately by "cock.wav" sound (included in zip).  If it's easier to have just one trigger at the start of the re-load sequence, let me know and I'll join the two sounds into one timed .wav file.

3. Dryfire sound is triggered on mouse-up (should be mouse-down).  Not a big deal, but does not feel "right".  This is true of all the weapons.

4. Ejected shell cases seem to appear above and to the front of the gun and then fall to the left.  They should first appear above ejection port on RH side and move (or fall) away to the right. 

5. This gun is also prone to double triggering the "fire.wav" sound.  I've discovered that by adding 1/100 sec. or so of silence before the sound starts, greatly reduces this problem.  This makes me think that FPSC is probably double triggering all weapon sounds, but it's only obvious on sounds that have zero lead-in and vertical attack.  Might be worth opening the bonnet to do some tightening in there to save the system doing unnecessary work. 

That's it for for this one!
 
Rick Harrison.
