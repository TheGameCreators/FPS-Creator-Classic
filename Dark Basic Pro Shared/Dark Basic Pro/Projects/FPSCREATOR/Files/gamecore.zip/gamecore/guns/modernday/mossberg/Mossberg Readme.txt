Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

reload.wav

dryfire.wav

NEW EXTRA SOUNDS:

cock.wav

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... Mossberg

1. The animation sequence for this gun is quite wrong.  When reloading, it has a capacity of only two shells.  The real gun can be loaded with 5 x 3 inch shells.  For the two shells the gun currently carries, there is only one cocking action.  In reality, the pump must be actuated after every shot to reload the gun's single chamber with the next round

2. I tried modifying the gunspec file to change the looping in the animation to suit the new sounds, but it seems that not all of the animation parameters are determined from there.

3. Because of the animation problems, I haven't been able to test and time the sounds within FPSC.  If you decide to re-do the animation, I may have to re-time the reload and cock sounds to get reasonable synchronization.

4. I've included a demo of the sounds as a guide to what should happen when this gun is fired.
The demo sequence is: retrieve, fire x 5, dryfire, reload (5 shells), fire x 1, putaway.

That's it for for this one!
 
Rick Harrison.
