Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

reload.wav

dryfire.wav

NEW EXTRA SOUNDS:

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... Autoslug

1. I've included a "quick-fix" gunspec file which sets up the fire and reload sounds to work with the animation (works well @~ 35fps).  Can't seem to get putaway and retrieve to be triggered as they should on any of the weapons, I guess this will be worked out later.

Included gunspec file shoud be used when auditioning this sound set.

This weapon is pretty good as it stands.  However, one thing that I think would be an improvement (others may not agree), is the player shouldn't be able to fire as quickly as the MB can be pressed.  I think it would be better if the gun was set up to only fire again if the current "fire.wav" has finished playing.

That's it for for this one!
 
Rick Harrison.
