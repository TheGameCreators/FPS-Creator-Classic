Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

reload.wav

dryfire.wav

NEW EXTRA SOUNDS:

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

NEW SHARED SOUND:

explode.wav

This sound is to replace a file of the same name which is found in the \flak\[type]\[weapon] dir for the Bazooka (and others) and is the sound of the projectile exploding.

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... Bazooka

1. Picking up Ammo gives weapon (known bug on forums)

2. Picking up Ammo always gives three shots in weapon which is impossible in reality.  IMHO when picking up the weapon it should have one shot loaded.  When picking up Ammo with an empty weapon, the player should have to  press "R" to load the next shot.

3. Dryfire sound is triggered on mouse-up (should be mouse-down).  Not a big deal, but does not feel "right".

4. Muzzle flash is not appropriate for this type of weapon (rocket launcher).  I think a brief display of smoke decals might be better, but again, not a big deal.

5. Further to point 4,  some form of smoke trail attached to the projectiles would look great (because they are small rockets!).

That's it for for this one!
 
Rick Harrison.
