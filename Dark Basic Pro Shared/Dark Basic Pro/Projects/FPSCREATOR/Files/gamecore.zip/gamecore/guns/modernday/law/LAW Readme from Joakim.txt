Hi!

I got the honor re-rigging all stock weapons to my new animations, and some new cool hands made in cooperation with Sebastian Kim.

Because the gunspec went too massive with all the new animationframes I had to cut them out in order to get sounds playing.
This is just til there is a solution for this in an upcoming update.

Also notice that not work has been laid upon the extra sounds, this will come in a future update.

Cheers!
Joakim Olsson
aka Cyborg Art

jammed	= 606,612
fix jam	= 620,669

zoomto =207,212
zoom idle =213,233
zoom move =236,259
zoom start fire =261,264
zoom automatic fire =265,271
zoom end fire = 272,276
zoomfrom =279,284

checkammo standard = 285,327
checkammo special = 328,375
changeammo st =	421,470
changeammo sp = 376,420

hold down start	= 471,478
hold down idle	= 479,510
hold down end	= 512,518

mod start	= 519,535
mod idle	= 537,569
mod end		= 571,585

run		= 586,605

putaway 2	= 684,694
select 2	= 694,710

change firemode	= 670,683

melee start 	= 714,719
melee end	= 720,733
melee hand start= 734,742
melee hand end	= 743,750
grenade start	= 751,761
grenade end	= 762,770

command attack	= 771,796
command regroup	= 797,832
command hold	= 833,856

bayonet start	= 857,863
bayonet	end	= 864,869

hand push	= 870,888
hand dead	= 889,945
hand door	= 946,977
hand button	= 978,997
hand take	= 998,1025