Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

reload.wav

dryfire.wav (shared)

NEW EXTRA SOUNDS:

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... MAS36

1. I've included a "quick-fix" gunspec file which sets up the fire and reload sounds to work with the animation (works well @~ 35fps).  I'd really like to find out how to introduce the retrieve and putaway sounds via the gunspec file but haven't had time to experiment much.  Anyway I'm sure you guys know how to set that up!

I haven't created a new "zoom" sound, simply because I think the current one is spot-on.  However if you would like me to do one, let me know.

Can't really think of any improvements on this weapon, it looks and sounds great!

That's it for for this one!
 
Rick Harrison.
