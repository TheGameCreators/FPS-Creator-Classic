Hi all,

Files included are now named the same as the files they should replace in the applicable weapon folder i.e.

MAIN SOUNDS:

fire.wav

dryfire.wav

NEW EXTRA SOUNDS:

putaway.wav (when pressing "0")

retrieve.wav (when pressing allocated weapon number key)

explode.wav.  (This sound is to replace a file of the same name which is found in the \flak\modernday\law dir, and is the sound of the projectile exploding.)

_________________________________________________________


IMPROVEMENT RECOMMENDATIONS... LAW

1. The LAW is a single use weapon which is discarded after each shot, but in the EA, the weapon stays on the screen and fires as quickly as the player can press the MB.  For more realism, why not have it disappear after each shot (putaway animation and sound) and have the player press the allocated number key to "pick-up" a fresh one (retrieve animation and sound) before being able to fire again?

2. Some form of smoke trail attached to the projectiles would look great (because they are small rockets!).

That's it for for this one!
 
Rick Harrison.
